#include "Entity.h"
/*#include <windows.h>
#include <gl\GL.h>
#include <glut.h>*/
#include <GL/glut.h>
#include <vector>
#include "Vector3.h"

using namespace std;
 

 
      Entity::Entity(){
      
      }

      Entity::~Entity(){
      
      }
      
     Vector3* Entity::getPosition(){
      return _position;
      }
      
  /*    Vector3* setPosition(double in_x, double in_y, double in_z){
      
      }
      
      Vector3* getPosition( const Vector3 &in_p){
      
      } */
     



