#include "Luz.h"


Luz::Luz(float x, float y, float z)
{
	_posX = x;
	_posY = y;
	_posZ = z;
	_active = 0;
}





