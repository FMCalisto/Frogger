/*#include <windows.h>
#include <gl\GL.h>
#include <glut.h>*/

#include <GL/glut.h>


#include "StaticObject.h"
//#include <GL/glut.h>

using namespace std;




		StaticObject::StaticObject(){
		
		}
		
/*		~StaticObject::StaticObject(){
		
		}*/

