#include"Camera.h"
#include "Vector3.h"
#include<stdio.h>

using namespace std;




		Camera::Camera(){
		
		}

		Camera::~Camera(){
		//hide=true;
		}

        void Camera::update(GLsizei w, GLsizei h, double atX, double atY, double atZ){}
        
        void Camera::computeProjectionMatrix(){}
        void Camera::computeVisualizationMatrix(){}


		
		
	 
