#ifndef StaticObject_H
#define StaticObject_H

#include"Entity.h"
#include"GameObject.h"




class StaticObject : public GameObject {
	public:
		StaticObject();
		~StaticObject();

};
#endif 
