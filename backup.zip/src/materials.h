#pragma once

#include "material.h"

struct materials {
    static  material rubber_black, rubber_red, metal_gold, skin_green, cyan_plastic, road_black, road_white,road_margin,
        perfect_reflector;
};
